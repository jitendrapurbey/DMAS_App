package com.example.jitendra.dmas;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MultiplicationFragment extends Fragment{


    View view;
    EditText num1,num2;
    Button btn;
    Double x,y;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_subtraction, container, false);


        num1= (EditText) view.findViewById(R.id.editText);
        num2= (EditText) view.findViewById(R.id.editText2);
        btn= (Button) view.findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double x=Double.parseDouble(num1.getText().toString());
                Double y=Double.parseDouble(num2.getText().toString());

                // display a message by using a Toast
                Toast.makeText(getActivity(), "Multiplication ="+(x*y), Toast.LENGTH_LONG).show();
            }
        });



        return view;
    }

}






